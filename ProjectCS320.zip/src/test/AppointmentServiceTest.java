package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import appointmentservice.Appointment;
import appointmentservice.AppointmentService;

public class AppointmentServiceTest {
	private AppointmentService service;
	
	@BeforeEach
	public void setUp() {
		service = new AppointmentService();
	}
	
	// test adding a appointment
	@Test
	public void testAddAppointment() {
		Appointment appointment = new Appointment("1", "Doctor Visit", "Cheackup at 10 AM");
		service.addAppointment(appointment);
		assertEquals(appointment, service.getAppointment("1"));
	}
	
	// test adding a duplicate appointment ID throws an exception
	@Test
	public void testAddDuplicateAppointmentThrowsError() {
		Appointment appointment1 = new Appointment("1", "Doctor Visit", "Cheackup at 10 AM");
		Appointment appointment2 = new appointment("1", "Meeting", "Project meeting at 2 PM");
		service.addAppointment(appointment1);
		assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appointment2));
	}
	
	// test deleting a appointment
	@Test
	public void testDeleteAppointment() {
		Appointment appointment = new Appointment("1", "Doctor Visit", "Checkup at 10 AM");
		service.addAppointment(appointment);
		service.deleteAppointment("1");
		assertNull(service.getAppointment("1"));
	}
	
	// test updating appointment name
	@Test
	public void testUpdateAppointmentName() {
		Appointment appointment = new appointment("1", "Doctor Visit", "Checkup at 10 AM");
		service.addAppointment(appointment);
		service.updateAppointmentName("1", "Dentist Visit");
		assertEquals("Dentist Visit", service.getAppointment("1").getName());
	}
	
	// test updating appointment description
	@Test
    public void testUpdateAppointmentDescription() {
		Appointment appointment = new Appointment("1", "Doctor Visit", "Checkup at 10 AM");
        service.addAppointment(appointment);
        service.updateAppointmentDescription("1", "Checkup at 11 AM);
        assertEquals("Checkup at 11 AM", service.getAppointment("1").getDescription());
    }
}
