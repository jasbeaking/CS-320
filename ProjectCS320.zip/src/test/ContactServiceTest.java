package contactservice.test;

import contactservice.Contact;
import contactservice.ContactService;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
	private ContactService service;
	
	@BeforeEach
	public void setUp() {
		service = new ContactService();
	}
	
	// test adding a contact
	@Test
	public void testAddContact() {
		Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
		service.addContact(contact);
		assertEquals(contact, service.getContact("1"));
	}
	
	// test adding a duplicate contact ID throws an exception
	@Test
	public void testAddDuplicateContactThrowsError() {
		Contact contact1 = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
		Contact contact2 = new Contact("1", "Jane", "Smith", "0987654321", "456 Oak Ave");
		service.addContact(contact1);
		assertThrows(IllegalArgumentException.class, () -> service.addContact(contact2));
	}
	
	// test deleting a contact
	@Test
	public void testDeleteContact() {
		Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
		service.addContact(contact);
		service.deleteContact("1");
		assertNull(service.getContact("1"));
	}
	
	// test updating first name
	@Test
	public void testUpdateFirstName() {
		Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
		service.addContact(contact);
		service.updateFirstName("1", "Jane");
		assertEquals("Jane", service.getContact("1").getFirstName());
	}
	
	// test updating last name
	@Test
    public void testUpdateLastName() {
        Contact contact = new Contact("2", "Alice", "Smith", "1112223333", "456 Oak Ave");
        service.addContact(contact);
        service.updateLastName("2", "Johnson");
        assertEquals("Johnson", service.getContact("2").getLastName());
    }
	
	// test updating phone number
	@Test
	public void testUpdatePhone() {
        Contact contact = new Contact("3", "Bob", "Brown", "2223334444", "789 Pine Rd");
        service.addContact(contact);
        service.updatePhone("3", "9998887777");
        assertEquals("9998887777", service.getContact("3").getPhone());
    }
	
	
	// test updating address
	@Test
	public void testUpdateAddress() {
        Contact contact = new Contact("4", "Carol", "White", "3334445555", "321 Elm St");
        service.addContact(contact);
        service.updateAddress("4", "654 Maple St");
        assertEquals("654 Maple St", service.getContact("4").getAddress());
    }
}
