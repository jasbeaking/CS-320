package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import appointmentservice.Appointment;

public class AppointmentTest {
	
	// Test valid appointment creation
	@Test
    public void testValidAppointmentCreation() {
		Appointment appointment = new Appointment("12345", "Doctor Visit", "Checkup at 10 AM");
        assertEquals("12345", appointment.getAppointmentId());
        assertEquals("Doctors Visit", appointment.getName());
        assertEquals("Checkup at 10 AM", appointment.getDescription());
    }

	// Test invalid appointment ID: null or too long
	@Test
    public void testInvalidAppointmentID() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, "Doctors Visit", "Checkup at 10 AM");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", "Doctors Visit", "Checkup at 10 AM"); // 11 chars
        });
    }

	// Test invalid name: null or too long
    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Checkup at 10 AM");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", "ThisAppointmentNameIsDefinitelyTooLong", "Checkup at 10 AM");
        });
    }

    // Test invalid description: null or too long
    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", "Doctors Visit", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", "Doctors Visit", "This description is way too long and should throw an error because it exceeds fifty characters in length");
        });
    } 
}