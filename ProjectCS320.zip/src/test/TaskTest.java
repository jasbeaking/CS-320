package taskservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import taskservice.Task;

public class TaskTest {
	
	// Test valid task creation
	@Test
    public void testValidTasktCreation() {
        Task task = new Task("12345", "Write report", "Complete the quarterly report");
        assertEquals("12345", task.getTaskId());
        assertEquals("Write report", task.getName());
        assertEquals("Complete the quarterly report", task.getDescription());
    }

	// Test invalid task ID: null or too long
	@Test
    public void testInvalidTaskID() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Write report", "Complete the quarterly report");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Write report", "Complete the quarterly"); // 11 chars
        });
    }

	// Test invalid name: null or too long
    @Test
    public void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Complete the quarterly report");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "ThisTaskNameIsDefinitelyTooLong", "Complete the quarterly report");
        });
    }

    // Test invalid description: null or too long
    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Write report", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Write report", "This description is way too long and should throw an error because it exceeds fifty characters in length");
        });
    } 
}