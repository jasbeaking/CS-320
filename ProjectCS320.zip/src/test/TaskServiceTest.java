package taskservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import taskservice.Task;
import taskservice.TaskService;

public class TaskServiceTest {
	private TaskService service;
	
	@BeforeEach
	public void setUp() {
		service = new TaskService();
	}
	
	// test adding a task
	@Test
	public void testAddTask() {
		Task task = new Task("1", "Write report", "Finish writing report by Friday");
		service.addTask(task);
		assertEquals(task, service.getTask("1"));
	}
	
	// test adding a duplicate task ID throws an exception
	@Test
	public void testAddDuplicateTaskThrowsError() {
		Task task1 = new Task("1", "Write report", "Finish report");
		Task task2 = new Task("1", "Prepare slides", "Create presentation slides");
		service.addTask(task1);
		assertThrows(IllegalArgumentException.class, () -> service.addTask(task2));
	}
	
	// test deleting a task
	@Test
	public void testDeleteTask() {
		Task task = new Task("1", "Write report", "Finish report");
		service.addTask(task);
		service.deleteTask("1");
		assertNull(service.getTask("1"));
	}
	
	// test updating task name
	@Test
	public void testUpdateTaskName() {
		Task task = new Task("1", "Write report", "Finish report");
		service.addTask(task);
		service.updateTaskName("1", "Prepare slides");
		assertEquals("Prepare slides", service.getTask("1").getName());
	}
	
	// test updating task description
	@Test
    public void testUpdateTaskDescription() {
        Task task = new Task("1", "Write report", "Finish report");
        service.addTask(task);
        service.updateTaskDescription("1", "Finish report by Friday");
        assertEquals("Finish report by Friday", service.getTask("1").getDescription());
    }
}
