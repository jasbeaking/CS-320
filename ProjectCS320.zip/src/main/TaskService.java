package taskservice;

import java.util.HashMap;
import java.util.Map;

/**
 * TaskService class manages Task objects in memory.
 * Supports adding, deleting, and updating tasks.
 */

public class TaskService {
	// in-memory storage of tasks: key = taskID, value = Task object
	private Map<String, Task> tasks = new HashMap<>();
	
	/**
	 * Adds a new task to the service.
	 * Ensures the task ID is unique.
	 * @param task the Task object to add
	 * @throws IllegalArgumentException if task ID already exists
	 */
	
	public void addTask(Task task) {
		if (tasks.containsKey(task.getTaskId())) {
			throw new IllegalArgumentException("Duplicate task ID");
		}
		tasks.put(task.getTaskId(), task);
	}
	
	/**
	 * deletes a task by its ID.
	 * @param taskId the ID of the task to delete
	 * @throws IllegalArgumentException if task ID is null or not found
	 */
	public void deleteTask(String taskId) {
		if (taskId == null || !tasks.containsKey(taskId)) {
			throw new IllegalArgumentException("Task ID not found");
		}
		tasks.remove(taskId);
	}
	
	/**
	 * updates the name of the task with the given ID
	 * @param taskId the task ID
	 * @param name new task name
	 * @throws IllegalArgumentException if task ID not found
	 */
	public void updateTaskName(String taskId, String name) {
		Task task = tasks.get(taskId);
		if (task == null) {
			throw new IllegalArgumentException("Task ID not found");
		}
		task.setName(name);
	}
	
	/**
	 * Updates the description of the task with the given ID.
	 * @param taskId the task ID
	 * @param description new description
	 */
	public void updateTaskDescription(String taskId, String decription) {
		Task task = tasks.get(taskId);
		if (task == null) {
			throw new IllegalArgumentException("Task ID not found");
		}
		task.setDescription(description);
	}
	
	/**
	 * Retrieves a task by its ID.
	 * @param taskId the task ID
	 * @return the Task object, or null if not found
	 */
	public Task getTask(String taskId) {
		return tasks.get(taskId);
	}
}
