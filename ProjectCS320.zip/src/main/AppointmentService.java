package appointmentservice;

import java.util.HashMap;
import java.util.Map;

/**
 * Appointmentervice class manages Appointment objects in memory.
 * Supports adding, deleting, and updating appointments.
 */

public class AppointmentService {
	// in-memory storage of appointments: key = appointmentID, value = Appointment object
	private Map<String, Appointment> appointments = new HashMap<>();
	
	/**
	 * Adds a new appointment to the service.
	 * Ensures the appointment ID is unique.
	 * @param appointment the Appointment object to add
	 * @throws IllegalArgumentException if appointment ID already exists
	 */
	
	public void addAppointment(Appointment appointment) {
		if (appointments.containsKey(appointment.getAppointmentId())) {
			throw new IllegalArgumentException("Duplicate appointment ID");
		}
		appointments.put(appointment.getAppointmentId(), appointment);
	}
	
	/**
	 * deletes a appointment by its ID.
	 * @param appointmentId the ID of the appointment to delete
	 * @throws IllegalArgumentException if appointment ID is null or not found
	 */
	public void deleteAppointment(String appointmentId) {
		if (appointmentId == null || !appointments.containsKey(appointmentId)) {
			throw new IllegalArgumentException("Appointment ID not found");
		}
		appointments.remove(appointmentId);
	}
	
	/**
	 * updates the name of the appointment with the given ID
	 * @param appointmentId the appointment ID
	 * @param name new appointment name
	 * @throws IllegalArgumentException if appointment ID not found
	 */
	public void updateAppointmentName(String appointmentId, String name) {
		Appointment appointment = appointments.get(appointmentId);
		if (appointment == null) {
			throw new IllegalArgumentException("Appointment ID not found");
		}
		appointment.setName(name);
	}
	
	/**
	 * Updates the description of the appointment with the given ID.
	 * @param appointmentId the appointment ID
	 * @param description new description
	 */
	public void updateAppointmentDescription(String appointmentId, String decription) {
		Appointment appointment = appointments.get(appointmentId);
		if (appointment == null) {
			throw new IllegalArgumentException("Appointment ID not found");
		}
		appointment.setDescription(description);
	}
	
	/**
	 * Retrieves a appointment by its ID.
	 * @param appointmentId the appointment ID
	 * @return the Appointment object, or null if not found
	 */
	public Appointment getAppointment(String appointmentId) {
		return appointments.get(appointmentId);
	}
}
