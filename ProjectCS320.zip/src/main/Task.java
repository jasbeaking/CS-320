package taskservice;

public class Task {
	private final String taskId;
    private String name;
    private String description;
    
    // constructor ensures all fields meet requirements before creating a Task object
    public Task(String taskId, String name, String description) {
    	// Task ID: required, unique, <= 10 chars, cannot be null
    	if (taskId == null || taskId.length() > 10) {
    		throw new IllegalArgumentException("Invalid task ID");
    	}
    	if (name == null || name.length() > 20) {
    		throw new IllegalArgumentException("Invalid task name");
    	}
    	if (description == null || description.length() > 10) {
            throw new IllegalArgumentException("Invalid task description");
    	}
    	
    	this.taskId = taskId;
    	this.name = name;
    	this.description = description;
    }
    
    // getters
    public String getTaskId() { return taskId; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    
    // setters (no setter for taskId since it's final)
    public void setName (String name) {
    	if (name == null || name.length() > 20){
    		throw new IllegalArgumentException("Invalid task name");
    	}
    	this.name = name;
    }
    public void setDescription(String description) {
    	if (description == null || description.length() > 50) {
    		throw new IllegalArgumentException("Invalid task description");
    	}
    	this.description = description;
    }
}
