package contactservice;

import java.util.HashMap;
import java.util.Map;

/**
 * ContactService class manages COntact objects in memory.
 * Supports adding, deleting, and updating contacts.
 */

public class ContactService {
	// in-memory storage of contacts: key = contactID, value = Contact object
	private Map<String, Contact> contacts = new HashMap<>();
	
	/**
	 * Adds a new contact to the service.
	 * Ensures the contact ID is unique.
	 * @param contact the Contact object to add
	 * @throws IllegalArgumentException if contact ID already exists
	 */
	
	public void addContact(Contact contact) {
		if (contacts.containsKey(contact.getContactId())) {
			throw new IllegalArgumentException("Duplicate contact ID");
		}
		contacts.put(contact.getContactId(), contact);
	}
	
	/**
	 * deletes a contact by its ID.
	 * @param contactId the ID of the contact to delete
	 * @throws IllegalArgumentException if contact ID is null or not found
	 */
	public void deleteContact(String contactId) {
		if (contactId == null || !contacts.containsKey(contactId)) {
			throw new IllegalArgumentException("Contact ID not found");
		}
		contacts.remove(contactId);
	}
	
	/**
	 * updates the first name of the contact with the given ID
	 * @param contactId the contact ID
	 * @param firstName new first name
	 * @throws IllegalArgumentException if contact ID not found
	 */
	public void updateFirstName(String contactId, String firstName) {
		Contact contact = contacts.get(contactId);
		if (contact == null) {
			throw new IllegalArgumentException("Contact ID not found");
		}
		contact.setFirstName(firstName);
	}
	
	/**
	 * Updates the last name of the contact with the given ID.
	 * @param contactId
	 * @param lastName
	 */
	public void updateLastName(String contactId, String lastName) {
		Contact contact = contacts.get(contactId);
		if (contact == null) {
			throw new IllegalArgumentException("Contact ID not found");
		}
		contact.setLastName(lastName);
	}
	
	/**
	 * Updates the phone number of the contact with the given ID.
	 * @param contactId
	 * @param phone
	 */
	public void updatePhone(String contactId, String phone) {
		Contact contact = contacts.get(contactId);
		if (contact == null) {
			throw new IllegalArgumentException("Contact ID not found");
		}
		contact.setPhone(phone);
	}
	
	/**
	 * Updates the address of the contact with the given ID.
	 */
	public void updateAddress(String contactId, String address) {
		Contact contact = contacts.get(contactId);
		if (contact == null) {
			throw new IllegalArgumentException("Contact ID not found");
		}
		contact.setAddress(address);
	}
	
	/**
	 * Retrieves a contact by its ID.
	 * @param contactId the contact ID
	 * @return the Contact object, or null if not found
	 */
	public Contact getContact(String contactId) {
		return contacts.get(contactId);
	}

}
