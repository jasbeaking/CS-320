package appointmentservice;

public class Appointment {
	private final String appointmentId;
    private String name;
    private String description;
    
    // constructor ensures all fields meet requirements before creating a Appointment object
    public Appointment(String appointmentId, String name, String description) {
    	// Appointment ID: required, unique, <= 10 chars, cannot be null
    	if (appointmentId == null ||appointmentId.length() > 10) {
    		throw new IllegalArgumentException("Invalid appointment ID");
    	}
    	if (name == null || name.length() > 20) {
    		throw new IllegalArgumentException("Invalid appointment name");
    	}
    	if (description == null || description.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment description");
    	}
    	
    	this.appointmentId = appointmentId;
    	this.name = name;
    	this.description = description;
    }
    
    // getters
    public String getAppointmentId() { return appointmentId; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    
    // setters (no setter for appointmentId since it's final)
    public void setName (String name) {
    	if (name == null || name.length() > 20){
    		throw new IllegalArgumentException("Invalid appointment name");
    	}
    	this.name = name;
    }
    public void setDescription(String description) {
    	if (description == null || description.length() > 50) {
    		throw new IllegalArgumentException("Invalid appointment description");
    	}
    	this.description = description;
    }
}
